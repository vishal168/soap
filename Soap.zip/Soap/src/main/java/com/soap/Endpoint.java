package com.soap;


import com.spring.soap_api.courses.CourseDetails;
import com.spring.soap_api.courses.GetCourseDetailsRequest;
import com.spring.soap_api.courses.GetCourseDetailsResponse;
import com.spring.soap_api.employees.GetEmployeeDetailsRequest;
import com.spring.soap_api.employees.GetEmployeeDetailsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@org.springframework.ws.server.endpoint.annotation.Endpoint
public class Endpoint {

    public static final String url = "http://localhost:8080/";
//
//    @Autowired
//    RestTemplate restTemplate;

    @PayloadRoot(namespace = "http://spring.com/soap.api/courses", localPart = "GetCourseDetailsRequest")
    @ResponsePayload
    public GetCourseDetailsResponse processCourseDetailsRequest(@RequestPayload GetCourseDetailsRequest request){
        GetCourseDetailsResponse response = new GetCourseDetailsResponse();
        CourseDetails courseDetails = new CourseDetails();
        courseDetails.setId(request.getId());
        courseDetails.setName("SpringBootSOAP");
        courseDetails.setDescription("This is a SOAP project");
        response.setCourseDetails(courseDetails);
        return response;
    }


    @PayloadRoot(namespace = "http://spring.com/soap.api/employees", localPart = "GetEmployeeDetailsRequest")
    @ResponsePayload
    public GetEmployeeDetailsResponse processEmployeeDetailsResponse(@RequestPayload GetEmployeeDetailsRequest request){



        GetEmployeeDetailsResponse response = new GetEmployeeDetailsResponse();
        response.setEmployeeid(request.getEmployeeid());
        response.setName("Employee1");
        response.setCompanyName("Infosys");

        return response;
    }
}
