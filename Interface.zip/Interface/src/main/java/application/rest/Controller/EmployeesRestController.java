package application.rest.Controller;

import application.rest.Entity.EmployeeVo;
import application.rest.Entity.Employee;
import application.rest.Service.EmployeeService;
import application.soap.EmployeeDetailsClient;
import com.example.consumingwebservice.wsdl.GetEmployeeDetailsRequest;
import com.example.consumingwebservice.wsdl.GetEmployeeDetailsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeesRestController {

    @Autowired
    EmployeeService employeeService;

    @Autowired
    private EmployeeDetailsClient client;

    @GetMapping("/employee")
    public EmployeeVo getEmployeeDetails(@RequestBody Employee employee){
        return employeeService.getEmployeeDetailsService(employee);
    }

    @PostMapping("/getEmployeeDetails")
    public GetEmployeeDetailsResponse invokeSoapClient(@RequestBody GetEmployeeDetailsRequest request){
        return client.getEmployeeDetails(request.getEmployeeid());
    }
}
