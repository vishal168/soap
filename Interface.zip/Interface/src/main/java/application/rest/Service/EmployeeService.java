package application.rest.Service;

import application.rest.Client.EmployeesDetailsClient;
import application.rest.Entity.EmployeeVo;
import application.rest.Entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

    @Autowired
    EmployeesDetailsClient employeesDetailsClient;


    public EmployeeVo getEmployeeDetailsService(Employee employee){
        return employeesDetailsClient.getEmployeeDetailsFromSoap(employee);
    }
}
