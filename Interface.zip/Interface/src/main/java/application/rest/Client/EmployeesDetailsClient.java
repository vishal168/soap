package application.rest.Client;

import application.rest.Entity.EmployeeDetails;
import application.rest.Entity.EmployeeVo;
import application.rest.Entity.Employee;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeesDetailsClient {

    public static final String EMPLOYEE_VOO_URL = "http://localhost:2222/employee";

//    @Autowired
//    RestTemplate restTemplate;



    public EmployeeVo getEmployeeDetailsFromSoap(Employee employee){
//        restTemplate.getForObject()

        EmployeeDetails employeeDetails = EmployeeDetails.builder()
                .id(employee.getId())
                .name("Vishal")
                .companyName("Infosys")
                .build();

        return EmployeeVo.builder().employeeDetails(employeeDetails).build();
    }
}
