package application.soap;

import com.example.consumingwebservice.wsdl.GetEmployeeDetailsRequest;
import com.example.consumingwebservice.wsdl.GetEmployeeDetailsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

public class EmployeeDetailsClient extends WebServiceGatewaySupport {

    private static final Logger log = LoggerFactory.getLogger(EmployeeDetailsClient.class);

    public GetEmployeeDetailsResponse getEmployeeDetails(int employeeid){

        GetEmployeeDetailsRequest request = new GetEmployeeDetailsRequest();
        request.setEmployeeid(employeeid);

        log.info("Requesting details for " + employeeid);

        GetEmployeeDetailsResponse response = (GetEmployeeDetailsResponse) getWebServiceTemplate()
                .marshalSendAndReceive("http://localhost:8080/getEmpInfo", request,
                        new SoapActionCallback("\"http://spring.io/guides/gs-producing-web-service/GetCountryRequest\""));

        return response;

    }
}
